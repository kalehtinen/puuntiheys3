package servlet;

import java.io.IOException;
import java.text.DecimalFormat;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import database.JDBCprotila;
import database.ProListDao;
import model.ProListItem;

@WebServlet("/pro")
public class ProServlet extends HttpServlet {

	JDBCprotila database = new JDBCprotila();

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		// Otetaan index.jsp:stä samat arvot

		String paksuus = req.getParameter("paksuus");
		String grain = req.getParameter("grain");
		String pituus = req.getParameter("pituus");
		String leveys = req.getParameter("leveys");
		String paino = req.getParameter("paino");

		// String muutettava Doubliksi, jotta voidaan laskea

		double paksuusDouble = Double.parseDouble(paksuus);
		double pituusDouble = Double.parseDouble(pituus);
		double leveysDouble = Double.parseDouble(leveys);
		double painoDouble = Double.parseDouble(paino);

		// Lasketaan puun tiheys ja tilavuus

		double tilavuusmm3 = (paksuusDouble * pituusDouble * leveysDouble);
		double tiheys = (painoDouble / 1000.0) / (tilavuusmm3 / 1000000000.0);
		System.out.println(tiheys);

		ProListItem item = new ProListItem(tiheys, grain, pituus, leveys, paino, paksuus);

		database.addItem(item);
		System.out.println(database.getAllItems());

		// Tiedot välitetään selaimelle

		req.setAttribute("tiheys", tiheys);

		// tiedot lähetetään index.jsp sivulle

		req.getRequestDispatcher("/WEB-INF/pro.jsp").forward(req, resp);
	}

	@Override
	public void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
		JDBCprotila tila = new JDBCprotila();
		DecimalFormat des = new DecimalFormat("0.00");

		try {
			String paksuus = req.getParameter("paksuus");
			String pituus = req.getParameter("pituus");
			String leveys = req.getParameter("leveys");
			String paino = req.getParameter("paino");
			String grain = req.getParameter("grain");
			double tiheys = Double.valueOf(req.getParameter("tiheys"));

			ProListItem item = new ProListItem(tiheys, grain, pituus, leveys, paino, paksuus);

			database.addItem(item);
			System.out.println(database.getAllItems());

		} catch (Exception e) {
			e.printStackTrace();
		}

		resp.sendRedirect("");

	}

	@Override
	protected void doDelete(HttpServletRequest req, HttpServletResponse resp) throws IOException {
		ProListDao dao = new JDBCprotila();
		int id = Integer.valueOf(req.getParameter("id"));

	}
}
