package servlet;

import database.JDBCprotila;
import model.ProListItem;

public class ProListProgram {

	/*
	 * public void poistaTuote(String puu) { ProListItem item = new ProListItem();
	 * item.setOsto(tuote); // JDBCShoppingListItemDao dao = new
	 * JDBCShoppingListItemDao(); database.removeItem(item);
	 * System.out.println("Successfully deleted " + tuote); System.out.println(); }
	 */

	public static void main(String[] args) {
		JDBCprotila database = new JDBCprotila();
		database.createTable();
		database.addItem(new ProListItem(2.0, "A", "2", "30", "40", "6"));
		database.addItem(new ProListItem(3.0, "B", "1", "68", "42", "9"));
		for (ProListItem item : database.getAllItems()) {
			System.out.println(item);
		}

	}

}
