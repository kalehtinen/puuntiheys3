package database;

import java.util.List;

import model.ProListItem;

public interface ProListDao {

	public List<ProListItem> getAllItems();

	public ProListItem getItem(long id);

	public boolean addItem(ProListItem newItem);

	public boolean removeItem(ProListItem item);
}
